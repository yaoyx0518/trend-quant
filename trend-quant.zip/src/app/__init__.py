﻿"""FastAPI app package."""
